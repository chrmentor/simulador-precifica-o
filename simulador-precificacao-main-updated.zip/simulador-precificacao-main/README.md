# simulador-precificacao
